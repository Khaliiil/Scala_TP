package tmdb

import scala.collection.immutable._

import scala.io.Source
import org.json4s._
import org.json4s.native.JsonMethods._

object Finder {
  def findActorId(name: String, surname: String): Option[Int] = {
    try {
      val request = Source.fromURL("https://api.themoviedb.org/3/search/person?api_key=0a3f9b1422abb8a0284f388056b138de&language=en-US&query=" +
        name + "%20" + surname + "&page=1&include_adult=false")
      request.close()
      val JSON = parse(request.mkString)
      Some(Integer.parseInt((JSON \ "results" \ "id").children.head.values.toString))


    } catch {
      case _: Exception => None
    }
  }

  def findActorMovies(id: Int): Set[(Int, String)] = {

    val request = Source.fromURL("https://api.themoviedb.org/3/person/" + id +
      "/movie_credits?api_key=0a3f9b1422abb8a0284f388056b138de&language=en-US")
    request.close()
    val JSON = parse(request.mkString)

    val titres = (JSON \ "cast" \ "title").children
    val ids = (JSON \ "cast" \ "id").children
    var ens = Set((Integer.parseInt(ids.head.values.toString), titres.head.values.toString))

    for (i <- 1 until titres.length) {
      ens += ((Integer.parseInt(ids(i).values.toString), titres(i).values.toString))
    }
    ens
  }

  def findMovieDirector(id: Int): Option[(Int, String)] = {


    try {
      val request = Source.fromURL("https://api.themoviedb.org/3/movie/" + id +
        "/credits?api_key=0a3f9b1422abb8a0284f388056b138de")
      val JSON = parse(request.mkString)
      val crew = (JSON \ "crew" \ "job").children
      val index = crew.indexOf(JString("Director"))
      Option((Integer.parseInt((JSON \ "crew" \ "id").children(index).values.toString),
        (JSON \ "crew" \ "name").children(index).values.toString))
    } catch {
      case _: Exception => None
    }
  }

  def request(actor1: FullName, actor2: FullName): Set[(String, String)] = {

    val idActor1 = findActorId(actor1.name, actor1.surname)
    val idActor2 = findActorId(actor2.name, actor2.surname)

    val moviesActor1 = findActorMovies(idActor1.getOrElse(0))
    val moviesActor2 = findActorMovies(idActor2.getOrElse(0))

    var ens: Set[(String, String)] = Set()

    for (i <- moviesActor1) {
      if (moviesActor2.contains(i)) {
        ens += ((findMovieDirector(i._1).head._2, i._2))
      }
    }
    ens

  }
}
