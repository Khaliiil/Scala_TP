package tmdb

case class FullName (
  name : String,
  surname : String
)
